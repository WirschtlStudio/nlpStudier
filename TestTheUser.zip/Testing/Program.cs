﻿using System.IO;
namespace Testing
{
    class Program
    {
        static async Task Main(string[] args)
        {
            #region format of .txt file
            /*format of .txt file:
                Garden;Garten
                Where was the earliest evidence of humans found?;Northwestern europe
                ...
                Question;Answer
            */
            #endregion
            Testing testing = new Testing();
            string path = @""; // .txt file;
            testing.GetQuestionsAndAnswers(path);

            string randomQ;
            string inputUser;
            bool result;

            while (true)
            {
                randomQ = testing.RandomQuestion();
                Console.WriteLine(randomQ);
                Console.WriteLine("Deine Anwort: ");
                inputUser = Console.ReadLine();
                result = testing.Check(inputUser);
                if (result)
                {
                    Console.WriteLine("Deine Anwort is korrekt");

                }
                else
                {
                    Console.WriteLine("falsche Antwort");
                    Console.WriteLine("Richtige Antwort wäre:{0}", testing.getAnswerOfRandomQuestion(randomQ));
                }
                Console.WriteLine("Dein Score:{0}", testing.PresentScore());
                Console.WriteLine("--------------------------------------------------------");
            }


        }
    }
}