﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Testing
{
    public class Testing
    {
        public int Score { get; set; }

        public int RandomNumber { get; set; }

        public int AmountOfQuestions { get; set; }
        public List<string> Answers { get; set; }
        public List<string> Questions { get; set; }


        /// <summary>
        /// Open the .txt file with the path as parameter
        /// Save the questions and solutions in lists
        /// </summary>
        /// <param name="path"></param>
        public void GetQuestionsAndAnswers(string path)
        {
            List<string> listQ = new List<string>();
            List<string> listA = new List<string>();


            using (var reader = new StreamReader(path))
            {


                while (!reader.EndOfStream)
                {
                    var line = reader.ReadLine();
                    var values = line.Split(';');

                    listQ.Add(values[0].ToLower());
                    listA.Add(values[1].ToLower());

                }
            }
            Questions = listQ;
            Answers = listA;
        }

        #region Check if User answered correctly
        /// <summary>
        /// If the question is more than a word we check the whole sentence
        /// if the question is only 1 word for example english vocabs, we check if the entire input word is equal to the solution
        /// </summary>
        /// <param name="answerUser"></param>
        /// <returns></returns>
        public bool Check(string answerUser)
        {
            AmountOfQuestions++;
            answerUser = answerUser.ToLower();
            string question = Questions[RandomNumber];
            string solution = getAnswerOfRandomQuestion(question);
            bool check = false;
            if (question.Contains(" "))
            {
                check = CheckSentence(answerUser, solution);
                if (check)
                {
                    Score++;

                }
                return check;
            }
            else
            {
                if (answerUser == solution)
                {
                    Score++;
                    return true;
                }
                return false;
            }



        }

        /// <summary>
        /// Compares each word of the sentence and the whole sentence
        /// But the whole sentence needs to be at least 80% equally
        /// </summary>
        /// <param name="answerUser"></param>
        /// <returns></returns>
        private bool CheckSentence(string answerUser, string solution)
        {

            string[] wordsUser = answerUser.Split(' ');
            string[] wordsSolution = solution.Split(" ");
            for (int i = 0; i < wordsSolution.Length; i++)
            {
                bool ifWordEqual = CheckIfEqualWord(wordsSolution[i], wordsUser[i]);
                if (!ifWordEqual)
                {
                    return false;
                }

            }
            bool IfSentenceEqual = CheckIfEqualSentence(solution, answerUser);
            if (!IfSentenceEqual)
            {
                return false;
            }
            return true;
        }

        /// <summary>
        /// Checks if the solutions and user input are equal.
        /// we check if the sentences are mostly equal with the percentage of 0.8
        /// </summary>
        /// <param name="solution"></param>
        /// <param name="answerUser"></param>
        /// <returns></returns>
        private bool CheckIfEqualSentence(string solution, string answerUser)
        {
            int equals = 0;

            for (int i = 0; i < solution.Length; i++)
            {


                if (solution[i] == answerUser[i])
                {
                    equals++;
                }

            }
            if (((double)equals / (double)solution.Length) >= 0.8)
            {
                return true;
            }
            return false;
        }
        /// <summary>
        /// The reason for this function is that small mistakes in the answer dont automatically means that it is a wrong answer
        /// Checks how many letters of the user answer and the solution are equal 
        /// if half of the word is equal, then the word is probably 
        /// </summary>
        /// <param name="idxWordSolution"></param>
        /// <param name="idxWordUser"></param>
        /// <returns></returns>
        private bool CheckIfEqualWord(string idxWordSolution, string idxWordUser)
        {
            int equals = 0;

            if (idxWordSolution.Length != idxWordUser.Length)
            {
                return false;
            }
            for (int i = 0; i < idxWordSolution.Length; i++)
            {

                if (idxWordSolution[i] == idxWordUser[i])
                {
                    equals++;
                }


            }
            if (((double)equals / (double)idxWordSolution.Length) >= 0.5)
            {
                return true;

            }
            else
            {
                return false;
            }
        }

        #endregion

        /// <summary>
        /// Returns a random questions of the List
        /// </summary>
        /// <returns></returns>
        public string RandomQuestion()
        {
            //List<string> questions = GetQuestions();
            Random rnd = new Random();
            RandomNumber = rnd.Next(1, Questions.Count);
            return Questions[RandomNumber];
        }
        /// <summary>
        /// Returns the answer of the random question
        /// </summary>
        /// <param name="question"></param>
        /// <returns></returns>
        public string getAnswerOfRandomQuestion(string question)
        {
            int index = Questions.IndexOf(question);
            return Answers[index];
        }


        /// <summary>
        /// Represents how many of the asked questions you answered correctly
        /// </summary>
        /// <returns></returns>
        public double PresentScore()
        {
            double res = (double)Score / (double)AmountOfQuestions;
            return res;
        }

    }
}
